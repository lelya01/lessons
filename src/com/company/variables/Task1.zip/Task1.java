package com.company.variables;

public class Task1 {
    public static void main(String[] args) {
        double calendarDates = 15.02;
        int calendarYear = 2002;

        final double numberPi = 3.14;

        int numberOfGuests;
        numberOfGuests = 15;
        int tableCups = numberOfGuests;
        int tableForks = numberOfGuests;


        int temperatureStorage = -3;

        System.out.print(calendarDates);
        System.out.print(".");
        System.out.println(calendarYear);
        System.out.println(numberPi);
        System.out.println(numberOfGuests);
        System.out.println(tableCups);
        System.out.println(tableForks);
        System.out.println(temperatureStorage);
    }
}
